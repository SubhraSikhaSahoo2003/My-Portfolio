
import React from 'react';

function App() {
  return (
    <div className="min-h-screen p-6 bg-white dark:bg-gray-900 text-black dark:text-white">
      <h1 className="text-4xl font-bold text-center mb-4">Subhra Sikha Sahoo</h1>
      <p className="text-center">Welcome to my portfolio site built with React and Tailwind CSS!</p>
    </div>
  );
}

export default App;
